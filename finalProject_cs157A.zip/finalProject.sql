##2. Create tables; MuffinType, OrderView, Customer, Invoice, Receipt,Event 
CREATE TABLE `MuffinType` (
  `productID` int,
  `muffinName` varchar(50),
  `description` varchar(50),
  `price` varchar(50),
  PRIMARY KEY (`productID`)
);

CREATE TABLE `OrderView` (
  `orderID` int,
  `productID` int,
  `quanitiy` int,
  PRIMARY KEY (`orderID`, `productID`),
  FOREIGN KEY (`productID`) REFERENCES `MuffinType`(`productID`)
);

CREATE TABLE `Customer` (
  `customerID` int,
  `firstName` varchar(50),
  `lastName` varchar(50),
  `address` varchar(50),
  `phone` varchar(50),
  `zip` varchar(5),
  PRIMARY KEY (`customerID`)
);

CREATE TABLE `Invoice` (
  `invoiceID` int,
  `totalPriceDue` varchar(50),
  `CustomerID` int,
  PRIMARY KEY (`invoiceID`),
  FOREIGN KEY (`customerID`) REFERENCES `Customer`(`customerID`)
);

CREATE TABLE `Receipt` (
  `receiptID` int,
  `pickUpDate` Date,
  `orderID` int,
  `customerID` int,
  `invoiceID` int,
  PRIMARY KEY (`receiptID`),
  FOREIGN KEY (`orderID`) REFERENCES `OrderView`(`orderID`),
  FOREIGN KEY (`customerID`) REFERENCES `Customer`(`customerID`),
  FOREIGN KEY (`invoiceID`) REFERENCES `Invoice`(`invoiceID`)
);

CREATE TABLE `Event` (
  `eventID` int,
  `description` varchar(50),
  `location` varchar(50),
  `date` date,
  `receiptID` int,
  PRIMARY KEY (`eventID`),
  FOREIGN KEY (`receiptID`) REFERENCES `Receipt`(`receiptID`)
);


##2. Insert iteams
 #customer table
INSERT INTO customer (customerID, firstName, lastName, address, phone, zip) VALUES 
(001,'Grace','Jung','Santa Clara', '650-345-2341','95054'),
(002,'Yousef','Sarras','mountain view', '435-645-1231','94039'),
(003,'Ana','Chang','San Jose', '234-345-2356','94560'),
(004,'Bene','Louis','Santa Clara', '453-534-1234','95054'),
(005,'Oliver','Lee','sunnyvale', '354-632-2345','94043'),
(006,'Jack','Ava','palo alto', '543-345-2343','94020'),
(007,'Noah','Lee','sunnyvale', '412-234-5234','94043'),
(008,'Ethan','Smith','Santa Clara', '543-234-5234','94560'),
(009,'John','Hong','palo alto', '123-234-5234','94020'),
(010,'Lucas','Choi','San Jose', '342-432-5233','94089'),
(011,'Mia','Asher','sunnyvale', '412-234-5234','94043'),
(012,'Henry','Luca','Santa Clara', '124-523-5323','95054'),
(013,'Nora','Haisley','palo alto', '765-432-1234','94020'),
(014,'Sam','Diego','mountain view', '475-234-6456','94039'),
(015,'Andy','Kim','San Jose', '645-456-2343','94089');

#muffintype table
INSERT INTO muffintype (productID, muffinName, description, price) VALUES 
(100,'cholocate muffine','this muffin put in the nutella cream on top...','13'),
(200,'vanilla muffine','this muffin put in the vanilla cream on top...','12'),
(300,'lemon muffine','this muffin put in the lemon slice on top...','15'),
(400,'blueberry muffine','this muffin put in the blueberry cream on top...','13'),
(500,'cinnamon muffine','this muffin put in the piece of cholate on top...','15')
;

#invoice table
INSERT INTO invoice(invoiceID, totalPriceDue, customerID) VALUES 
(011,'240','3'),
(012,'68','1'),
(013,'26','2'),
(014,'12','4'),
(015,'24','5'),
(016,'13','2'),
(017,'65','6'),
(018,'120','7'),
(019,'82','8'),
(020,'15','9'),
(021,'12','10'),
(022,'36','14'),
(023,'60','13'),
(024,'65','12'),
(025,'24','11'),
(026,'30','15'),
(027,'45','10')
;
#orderView event
INSERT INTO orderView (orderID, productID, quanitiy) VALUES 
(5551,100, 2),
(5552,200, 5),
(5553,300, 10),
(5554,400, 40),
(5555,500, 20),
(5556,300, 3),
(5557,200, 7) ;

#receipt receipt
INSERT INTO receipt(receiptID, pickUpDate, orderID, customerID, invoiceID) VALUES 
(1001,'2021-11-04',5551, 1, 011),
(1002,'2021-11-07',5552, 2, 012),
(1003,'2021-11-11',5553, 3, 013),
(1004,'2021-11-14',5554, 4, 014),
(1005,'2021-11-11',5555, 5, 015),
(1006,'2021-11-14',5557, 6, 016),
(1007,'2021-11-04',5556, 14, 017),
(1008,'2021-11-02',5551, 13, 020),
(1009,'2021-11-15',5557, 8, 023),
(1010,'2021-11-16',5554, 9, 025),
(1011,'2021-11-17',5555, 10, 026);

#order event
INSERT INTO event(eventID, description, location, date, receiptID) VALUES 
(11111, 'Holiday season greetings..','San Jose','2021-12-22', '1001'),
(11112, 'Happy 2022..,','Santa Clara','2021-12-31', '1002'),
(11113, 'Thanks giving Dinner party..','San Jose','2021-11-22', '1003'),
(11114, 'Birthday party..','Santa Clara','2021-09-04', '1007'),
(11116, 'Graudate party..','Palo Alto','2021-05-24', '1009'),
(11115, 'Church service..','Santa Clara','2021-11-02', '1010'),
(11117, 'Branch time..','Mountain view','2021-05-12', '1011');